#include "fsl_debug_console.h"
#include "fsl_port.h"
#include "fsl_gpio.h"
#include "fsl_common.h"
#include "board.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "cmsis_os.h"
#include "ELEC422.h"
#include "fsl_adc16.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
 //ADC Definitions
 
#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL1 12U

#define DEMO_ADC16_IRQn ADC0_IRQn
#define DEMO_ADC16_IRQ_HANDLER_FUNC ADC0_IRQHandler

#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL2 13U

#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL3 14U
 
#define ADC16_GetDefaultConfig
#define ADC16_Init
#define ADC16_DoAutoCalibration
#define ADC16_GetChannelStatusFlags
#define ADC16_SetChannelConfig




volatile bool g_Adc16ConversionDoneFlag = false;
volatile uint32_t g_Adc16ConversionValue;
volatile uint32_t g_Adc16InterruptCounter;



 
typedef struct{
	char mydata[128];
} mail_format;

osMailQDef(mail_box, 16, mail_format);
osMailQId mail_box;

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void DisplayThread( void const * argument);
osThreadId tid_DisplayThread;
osThreadDef (DisplayThread, osPriorityNormal, 1, 0);

void KeyboardThread( void const * argument);
osThreadId tid_KeyboardThread;
osThreadDef (KeyboardThread, osPriorityNormal, 1, 0);

void SW2Thread( void const * argument);
osThreadId tid_SW2Thread;
osThreadDef (SW2Thread, osPriorityNormal, 1, 0);

void SW3Thread( void const * argument);
osThreadId tid_SW3Thread;
osThreadDef (SW3Thread, osPriorityNormal, 1, 0);

void LEDThread( void const * argument);
osThreadId tid_LEDThread;
osThreadDef (LEDThread, osPriorityNormal, 1, 0);

void Pot1Thread( void const * argument);
osThreadId tid_Pot1Thread;
osThreadDef (Pot1Thread, osPriorityNormal, 1, 0);

void Pot2Thread( void const * argument);
osThreadId tid_Pot2Thread;
osThreadDef (Pot2Thread, osPriorityNormal, 1, 0);




/*******************************************************************************
 * Variables
 ******************************************************************************/
/* Whether the SW button is pressed */
osThreadId main_id;
/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Interrupt service fuction of switch.
 *
 
 
 
 
 
 * This function toggles the LED
 */
//ADC Methods
void definedDelay( unsigned long duration)
{
    while ( ( duration -- )!= 0);
}

void DEMO_ADC16_IRQ_HANDLER_FUNC(void)
{
    g_Adc16ConversionDoneFlag = true;
    /* Read conversion result to clear the conversion completed flag. */
    g_Adc16ConversionValue = ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP);
    g_Adc16InterruptCounter++;
}
 
 
void BOARD_SW3_IRQ_HANDLER(void)
{
uint32_t MyPinInput;
    /* Clear external interrupt flag. */
    GPIO_ClearPinsInterruptFlags(BOARD_SW3_GPIO, 1U << BOARD_SW3_GPIO_PIN);
    /* Change state of button. */
		MyPinInput = GPIO_ReadPinInput(BOARD_SW3_GPIO, BOARD_SW3_GPIO_PIN);
		osSignalSet(tid_SW3Thread, MyPinInput+1);
}

void BOARD_SW2_IRQ_HANDLER(void)
{
uint32_t MyPinInput;
    /* Clear external interrupt flag. */
    GPIO_ClearPinsInterruptFlags(BOARD_SW2_GPIO, 1U << BOARD_SW2_GPIO_PIN);
		MyPinInput = GPIO_ReadPinInput(BOARD_SW2_GPIO, BOARD_SW2_GPIO_PIN);
    /* Change state of button. */
		osSignalSet(tid_SW2Thread, MyPinInput+1);
	
}
// Display Thresd
void DisplayThread( void const * argument)
{
osEvent evt;
mail_format *MyReadData;
	
		mail_box = osMailCreate(osMailQ(mail_box), NULL);
	
		while(1)
		{
				evt = osMailGet(mail_box, osWaitForever);
				if(evt.status == osEventMail)
				{
					MyReadData = (mail_format*)evt.value.p;
					PRINTF("%s\n\r", MyReadData->mydata);
				}
				osMailFree(mail_box,MyReadData); 
		}
}

// Display Thresd
void KeyboardThread( void const * argument)
{
char readdata;
mail_format *MyKeyData;
	float samplingPeriod;
	
	
		while(1)
		{
				readdata = GETCHAR();
				MyKeyData = (mail_format*)osMailAlloc(mail_box,osWaitForever);
			
				MyKeyData->mydata[0] = readdata;
				MyKeyData->mydata[1] = 0;
				osMailPut(mail_box,MyKeyData); 
			
			switch (readdata){
				case ('r'):	osSignalSet(tid_LEDThread, 0x01); break;
				case ('R'):	osSignalSet(tid_LEDThread, 0x02); break;
				case ('g'):	osSignalSet(tid_LEDThread, 0x04); break;
				case ('G'):	osSignalSet(tid_LEDThread, 0x08); break;
				case ('b'):	osSignalSet(tid_LEDThread, 0x10); break;
				case ('B'):	osSignalSet(tid_LEDThread, 0x20); break;
		    case ('1'):	osSignalSet(tid_Pot1Thread, 0x24); break;
				case (' '):	osSignalSet(tid_Pot1Thread, 0x28); SCANF("%f ", &samplingPeriod); break;
				case ('2'):	osSignalSet(tid_Pot2Thread, 0x32); break;
			}
		}
		
	  
			
		
		
}

// SW2 Thresd
void SW2Thread( void const * argument)
{
mail_format *MySW2Data;
osEvent MyEvent;	
	
		while(1)
		{
				MyEvent  = osSignalWait(0x00, osWaitForever);
				MySW2Data = (mail_format*)osMailAlloc(mail_box,osWaitForever);
				if (MyEvent.value.signals == 0x01)
					{
						strcpy(MySW2Data->mydata, "Switch 2 Pressed");
					}
				else{
						strcpy(MySW2Data->mydata, "Switch 2 Released");
					}
				
				osMailPut(mail_box,MySW2Data); 
		}
}

// SW2 Thresd
void SW3Thread( void const * argument)
{

mail_format *MySW3Data;
osEvent MyEvent2;	
	
		while(1)
		{
				MyEvent2  = osSignalWait(0x00, osWaitForever);
				MySW3Data = (mail_format*)osMailAlloc(mail_box,osWaitForever);
				if (MyEvent2.value.signals == 0x01)
					{
						strcpy(MySW3Data->mydata, "Switch 3 Pressed");
					}
				else{
						strcpy(MySW3Data->mydata, "Switch 3 Released");
					}
				
				osMailPut(mail_box,MySW3Data); 
		}
}

// Colour Thread (Part B)
void LEDThread( void const * argument) {
osEvent MyEvent;	

	
	while (1) 
		{
				MyEvent = osSignalWait(0x00, osWaitForever);
				if (MyEvent.value.signals == 0x01)
					LED_Off(0);
				else if (MyEvent.value.signals == 0x02)
					LED_On(0);
				else if (MyEvent.value.signals == 0x04)
					LED_Off(1);
				else if (MyEvent.value.signals == 0x08)
					LED_On(1);
				else if (MyEvent.value.signals == 0x10)
					LED_Off(2);
				else if (MyEvent.value.signals == 0x20)
					LED_On(2);
		}
}

//Pot Method
void PotMethod () {
	
	 int voltage_integer;
   int voltage_decimal;
	 
	
	
    adc16_config_t adc16ConfigStruct;
    adc16_channel_config_t adc16ChannelConfigStruct;

    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
	
	 EnableIRQ(DEMO_ADC16_IRQn);

    PRINTF("\r\nPot 1 = 1.15V\r\n");
	
	

    
    // * adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceVref;
    // * adc16ConfigStruct.clockSource = kADC16_ClockSourceAsynchronousClock;
    // * adc16ConfigStruct.enableAsynchronousClock = true;
    // * adc16ConfigStruct.clockDivider = kADC16_ClockDivider8;
      adc16ConfigStruct.resolution = kADC16_ResolutionSE12Bit;
      adc16ConfigStruct.longSampleMode = kADC16_LongSampleDisabled;
    // * adc16ConfigStruct.enableHighSpeed = false;
    // * adc16ConfigStruct.enableLowPower = false;
    // * adc16ConfigStruct.enableContinuousConversion = false;
     
		 
		
		 
    ADC16_GetDefaultConfig(&adc16ConfigStruct);
    ADC16_Init(DEMO_ADC16_BASE, &adc16ConfigStruct);
    ADC16_EnableHardwareTrigger(DEMO_ADC16_BASE, false); /* Make sure the software trigger is used. */
#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
    if (kStatus_Success == ADC16_DoAutoCalibration(DEMO_ADC16_BASE))
    {
        PRINTF("ADC16_DoAutoCalibration() Done.\r\n");
    }
    else
    {
        PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
    }
#endif /* FSL_FEATURE_ADC16_HAS_CALIBRATION */
    PRINTF("Press any key to get user channel's ADC value ...\r\n");

    adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = false;
#if defined(FSL_FEATURE_ADC16_HAS_DIFF_MODE) && FSL_FEATURE_ADC16_HAS_DIFF_MODE
    adc16ChannelConfigStruct.enableDifferentialConversion = false;
#endif /* FSL_FEATURE_ADC16_HAS_DIFF_MODE */

    while (1)
    {
       
			
			 
			 GETCHAR();
			
			 g_Adc16ConversionDoneFlag = false;
			
        /*
         When in software trigger mode, each conversion would be launched once calling the "ADC16_ChannelConfigure()"
         function, which works like writing a conversion command and executing it. For another channel's conversion,
         just to change the "channelNumber" field in channel's configuration structure, and call the
         "ADC16_ChannelConfigure() again.
        */
			  adc16ChannelConfigStruct.channelNumber = DEMO_ADC16_USER_CHANNEL1; 
        ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
        while (0U == (kADC16_ChannelConversionDoneFlag &
                      ADC16_GetChannelStatusFlags(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP)))
        {
        }
				
        PRINTF("ADC1 ASCII Value: %d\r\n", ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP));
				g_Adc16ConversionValue=ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP);
				voltage_integer = g_Adc16ConversionValue/1000;
				voltage_decimal = g_Adc16ConversionValue - (g_Adc16ConversionValue/1000)*1000;
        PRINTF("Pot 1 = %d", voltage_integer );
				PRINTF(".%dV\r\n", voltage_decimal );
			  
				adc16ChannelConfigStruct.channelNumber = DEMO_ADC16_USER_CHANNEL2;
        ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
        while (0U == (kADC16_ChannelConversionDoneFlag &
                      ADC16_GetChannelStatusFlags(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP)))
        {
        }
				
				 
				
				if(GETCHAR() == '2')
				{
				
				definedDelay(1000);
					
				PRINTF("ADC2 ASCII Value: %d\r\n", ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP));
				}
				
				
    }
		
		

		

}


//Thread 6 for POT 1 ADC
void Pot1Thread( void const * argument)
{
	mail_format *potMessage;
osEvent MyEvent;
		MyEvent  = osSignalWait(0x00, osWaitForever);
				potMessage = (mail_format*)osMailAlloc(mail_box,osWaitForever);
	      if (MyEvent.value.signals == 0x24)
					{
						
						PotMethod();
						strcpy(potMessage->mydata, "POT 1 ADC is ");
						
					}
					
					osMailPut(mail_box,potMessage); 
		
	}		
//Thread 7 for POT 2 ADC
void Pot2Thread( void const * argument)
{
	mail_format *potMessage;
osEvent MyEvent;
		MyEvent  = osSignalWait(0x00, osWaitForever);
				potMessage = (mail_format*)osMailAlloc(mail_box,osWaitForever);
	      if (MyEvent.value.signals == 0x28 || MyEvent.value.signals ==0x32)
					{
						
						PotMethod();
						strcpy(potMessage->mydata, "POT 2 ADC is ");
						
					}
					
					osMailPut(mail_box,potMessage); 
	
	


	
}



int main(void)
{
	
	 
	
	
	  osKernelInitialize();									// Initialize and suspend the Kernel 
		elec422_startup();										// Configure some of the LEDs and switches
	
	PRINTF("\n\rPress SW2 or SW3 on the NXP Freedom board to generate their interrrupts, \n\rMoreover you can Press R for red, B for blue or G for green and you can make a colour combination\n");

	
   
		tid_DisplayThread = osThreadCreate(osThread(DisplayThread), NULL);
		tid_KeyboardThread = osThreadCreate(osThread(KeyboardThread), NULL);
		tid_SW2Thread = osThreadCreate(osThread(SW2Thread), NULL);
		tid_SW3Thread = osThreadCreate(osThread(SW3Thread), NULL);
    tid_LEDThread = osThreadCreate(osThread(LEDThread), NULL);
	  
    tid_Pot1Thread = osThreadCreate(osThread(Pot1Thread), NULL);
	  tid_Pot2Thread = osThreadCreate(osThread(Pot2Thread), NULL);
    	
	
		osKernelStart();											// start the RTOS
		
		main_id = osThreadGetId();						// Get the main Thread ID

		osThreadTerminate(main_id);						// and then terminate it

}

